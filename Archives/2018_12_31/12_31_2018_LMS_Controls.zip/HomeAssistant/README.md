## Home Assistant (HA) Installation Details
Your current HA installation must be updated with the all files contained in this directory tree.
Please read carefully the README.md files contained in each subdirectory for detailed instructions on the requirements and modifications required for tokens, passwords, keys, links, etc.. to make this operational.
